package com.jok92.workout_tracker_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutTrackerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
